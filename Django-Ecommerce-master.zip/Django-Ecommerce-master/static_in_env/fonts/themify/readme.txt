=====================================
HOW TO USE IT:

1) Upload the ‘themify-icons.css’ file and ‘fonts’ folder to your server

2) Add the CSS file into the <head> section of your site:
<link href="http://yoursite.com/themify-icons.css" rel="stylesheet">

3) Add the icon markup in your page:
<span class="ti-download"></span>

All icons can be viewed at: http://themify.me/themify-icons


=====================================
LICENSE

- Themify Icons font licensed under: http://scripts.sil.org/OFL
- Code licensed under: http://opensource.org/licenses/mit-license.html
- All brand icons are copyright/trademarks of their respective owners.


=====================================
VERSIONS

Version 1.0.1 (May 27, 2014)
- Added SVG format
- Fixed some icon naming issues
- Added rss icon

Version 1.0.0 (May 16, 2014)
- Initial release